<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//ROUTE..............

/*
1. route return simple statement
 Route syntax ---
Route::get('/linkName' , function(){
    return "Your statement";
});
*/
Route::get('/services', function(){
    return "This is my services";
});

/*
2. route return to a view (web page)
Route syntax --
Route::get('/linkName', function(){
    return view('viewName');
});
*/
Route::get('/services1', function(){
    return view('myServices');
});

/*
3. route accept parameter 
Route syntax --
Route::get('/linkName/{parameterName}', function($par){
   return $par;
});
##NOTE THAT "$par is the variable that will hold the value of the parameter"
*/
Route::get('/services2/{name}', function($par){
    return $par;
});
Route::get('/services3/{name}/{price}', function($par_n, $par_p){
    return "Service Name :" . $par_n . "/ Service Price :" . $par_p;
});
Route::get('/services4/all/{name}/{price}', function($par_n, $par_p){
    return "Service Name :" . $par_n . "/ Service Price :" . $par_p;
});

/* 
4. route accept parameter and return to a view (web page).
Route syntax --
Route::get('/linkName/{parameterName}', function($par){
    $arrayName['par'] = $par;
    return view('viewName', $arrayName);
});
##NOTE THAT 
"$arrayName is array that will hold all the 
parameters value we want to pass to the view"
*/
Route::get('/services5/{name}/{price}', function($par_n, $par_p){
    $data['array_n'] = $par_n;
    $data['array_p'] = $par_p;
    return view('myServices2', $data);
});

//.................................................................

//ROUTE AND CONTROLLER......

/*1. return simple statement 
Route syntax --
Route::get('/linkName', [App\Http\Controllers\ControllerName::class, 'functionName']);
*/
Route::get('/services6', [App\Http\Controllers\ServiceController::class, 'index']);

/*
2. return to a view (web page) 
Route syntax --
Route::get('/linkName', [App\Http\Controllers\ControllerName::class, 'functionName']);
*/
Route::get('/services7', [App\Http\Controllers\ServiceController::class, 'index2']);

/* 
3. accept parameter 
Route syntax --
Route::get('/linkName/{parameterName}', 
[App\Http\Controllers\ControllerName::class, 'functionName']);
*/
Route::get('/services8/{name}', [App\Http\Controllers\ServiceController::class, 'getName']);

/*
4. accept parameter and return to a view (web page)
Route syntax --
Route::get('/linkName/{parameterName}', 
[App\Http\Controllers\ControllerName::class, 'functionName']);
*/
Route::get('/services9/{name}/{price}', [App\Http\Controllers\ServiceController::class, 'getDetail']);

//............................................................
//Forms 

/*
1. Route to show the form
Route syntax --
Route::get('/linkName', [App\Http\Controllers\ControllerName::class, 'functionName']);
*/
Route::get('/form/show', [App\Http\Controllers\FormController::class, 'openForm']);

/*
2. Route to send the data from the form to the controller
Route syntax --
Route::post('/linkName', [App\Http\Controllers\ControllerName::class, 'functionName']);
*/
Route::post('/form/submit', [App\Http\Controllers\FormController::class, 'submitForm']);

Route::post('/form/submit1', [App\Http\Controllers\FormController::class, 'submitForm1']);
/* do not forget to change the action value in the form to 
/form/submit1 so we can run this the route */

//...............................................................................

//file storage 

//route to open the form 
Route::view('/form/storage', 'formView.uploadView');

//route to upload the file from the form to storage\app\public\logos
Route::post('/form/upload', [App\Http\Controllers\StorageController::class, 'uploadFile']);
