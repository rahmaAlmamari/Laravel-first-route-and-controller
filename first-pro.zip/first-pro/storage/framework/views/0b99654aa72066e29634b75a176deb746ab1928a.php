<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORM VIEW</title>
</head>
<body>
    <!-- 
        validation message code
    -->
    <ul>
    <?php if($errors -> any()): ?>
    <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <?php echo e($error); ?>

    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </ul>
    <form action="/form/submit1" method="post">
        <?php echo csrf_field(); ?> 
        <label for="">Name</label>
        <!--<input type="text" name="name" id="" required>-->
        <input type="text" name="name" id="">
        <br>
        <label for="">Email</label>
        <!--<input type="text" name="email" id="" required>-->
        <input type="text" name="email" id="">
        <br>
        <label for="">Password</label>
        <!--<input type="password" name="password" id="" required>-->
        <input type="password" name="password" id="">
        <br>
        <input type="submit" value="Submit">
    </form>
    <!--
        #NOTE THAT
        1. in the action we have to write the
           link name of the post route.
        2. in the method we have to write post,
           if we do not by defult ti will be get.
        3. we have to add <?php echo csrf_field(); ?> for scurity purpose.
    -->
</body>
</html><?php /**PATH C:\Users\Lenovo\Downloads\projects\first-pro\resources\views/formView/form.blade.php ENDPATH**/ ?>