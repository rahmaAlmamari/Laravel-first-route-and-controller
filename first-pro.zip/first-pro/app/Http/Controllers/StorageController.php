<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StorageController extends Controller
{
    public function uploadFile(Request $request)
    {
        $path = $request->file('logo')->store('public\logos');

        /*
        #NOTE THAT:
        1. avatar1 is the input name from the form which be
        for uploading our file.
        2. avatars2 is where we want to upload our file.
        */ 
 
        //return $path;

       $data['image'] = $path;
       return view('formView.showLogo', $data);
    }
}
