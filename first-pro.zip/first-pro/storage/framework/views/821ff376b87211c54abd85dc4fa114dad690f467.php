<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>my services 2</title>
</head>
<body>
    <!--
        we pass an array to this view 
        called $data which have two 
        variable (array_n , array_p)
     -->

     <h1>My Services Page:</h1>
     <br>
     <hr>
     <h3>Service Name : <?php echo e($array_n); ?></h3>
     <br>
     <h3>Service Price : <?php echo e($array_p); ?></h3>
</body>
</html><?php /**PATH C:\Users\Lenovo\Downloads\projects\first-pro\resources\views/myServices2.blade.php ENDPATH**/ ?>