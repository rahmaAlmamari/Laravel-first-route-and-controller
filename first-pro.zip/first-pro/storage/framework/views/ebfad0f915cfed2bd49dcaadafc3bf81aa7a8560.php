<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UPLOAD VIEW</title>
</head>
<body>
    <form action="/form/upload" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="">Upload your logo :</label>
        <input type="file" name="logo" id="">
        <br>
        <input type="submit" value="Upload">
    </form>
    <!-- 
        #NOTE THAT:
        enctype="multipart/form-data" 
        we have to add it in all the form which
        will be used to upload something.
    -->
</body>
</html><?php /**PATH C:\Users\Lenovo\Downloads\projects\first-pro\resources\views/formView/uploadView.blade.php ENDPATH**/ ?>