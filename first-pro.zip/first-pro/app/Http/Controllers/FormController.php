<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormController extends Controller
{
    //function to show the form
    public function openForm(){
        return view('formView.form');
    }
    //function to show all the dta from the form
    public function submitForm(Request $request){
        return $request;
    }
    //function to show one input dta from the form
    public function submitForm1(Request $request){
        $request -> validate([
            'email' => 'required',
            'name' => 'required|max:5',
            'password' => 'required',
            /*
            #NOTE THAT:
            name, email and password 
            is the input name from the form
            */ 
        ]);
        return $request -> email;
        /*
        #NOTE THAT: email is the name of the Email input
        */ 
    }
 
}
