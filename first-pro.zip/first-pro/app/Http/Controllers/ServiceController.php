<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ServiceController extends Controller
{
    //here we can write all the function related to the services

    /*
    1. return simple statement 
    function syntax --
    public function functionName(){
        return "Your statement";
    }
    */
    public function index(){
        return "Hi ... this is my services";
    }

    /*
    2. return to a view (web page) 
    function syntax --
    public function functionName(){
        return view('viewName');
    }
    */
    public function index2(){
        return view('myServices3');
    }

    /* 
    3. accept parameter 
    function syntax --
    public function functionName($par){
    return $par;
    }
    */
    public function getName($par_n){
        return "Service Name :" . $par_n;
    }

    /*
    4. accept parameter and return to a view (web page)
    function syntax --
    public function functionName($par){
      $arrayName['par'] = $par;
      return view('viewName', $arrayName);
    }
    ##NOTE THAT 
    "$arrayName is array that will hold all the 
    parameters value we want to pass to the view"
    */
    public function getDetail($par_n, $par_p){
        $data['array_n'] = $par_n;
        $data['array_p'] = $par_p;
        return view('myServices4', $data);
    }
}
