<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORM VIEW</title>
</head>
<body>
    <!-- 
        validation message code
    -->
    <ul>
    @if($errors -> any())
    @foreach($errors -> all() as $error)
    <li>
        {{$error}}
    </li>
    @endforeach
    @endif
    </ul>
    <form action="/form/submit1" method="post">
        @csrf 
        <label for="">Name</label>
        <!--<input type="text" name="name" id="" required>-->
        <input type="text" name="name" id="">
        <br>
        <label for="">Email</label>
        <!--<input type="text" name="email" id="" required>-->
        <input type="text" name="email" id="">
        <br>
        <label for="">Password</label>
        <!--<input type="password" name="password" id="" required>-->
        <input type="password" name="password" id="">
        <br>
        <input type="submit" value="Submit">
    </form>
    <!--
        #NOTE THAT
        1. in the action we have to write the
           link name of the post route.
        2. in the method we have to write post,
           if we do not by defult ti will be get.
        3. we have to add @csrf for scurity purpose.
    -->
</body>
</html>